exports = async function(userId, phoneNumber, sekrit){
  console.log('checking', userId, phoneNumber, sekrit)
    var collection = context.services.get("atlas").db("alerts").collection("2fa");
    
    return await collection.findOne(
      { "phoneNumber": phoneNumber }).then(async result=>{
if (result===null){ return console.error("I can't find a matching record");}
console.log('I found the record', JSON.stringify(result));
        if (result.current2fa.code == sekrit) {
          
          var usersCollection = context.services.get("atlas").db("alerts").collection("users");
          
          return await usersCollection.findOneAndUpdate({'_id': BSON.ObjectId(userId)}, 
            { $set:{'phone':phoneNumber, 'confirmed':true}}
            ).then(r=>{
              console.log(JSON.stringify(r));
            return {status: "success", message: "Your number has been confirmed."}
          }).catch(e=>{
            console.error(e);
          })
          
        } else {
          return {status: "error", message: "The code you entered didn't match the one we sent."}
        }
      }).catch(err=>{
        console.error(err)
      });
};